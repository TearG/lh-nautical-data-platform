import os
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

# ---- Configuração ----
BASE_DIR    = r"C:\Users\vanes\source\repos\nautical"
PROC_DIR    = os.path.join(BASE_DIR, "processed")
REPORT_DIR  = os.path.join(BASE_DIR, "outputs", "reports")

os.makedirs(REPORT_DIR, exist_ok=True)

def read_processed(name):
    return pd.read_csv(os.path.join(PROC_DIR, name))

def save_report(df, name):
    path = os.path.join(REPORT_DIR, name)
    df.to_csv(path, index=False, encoding='utf-8-sig')
    print(f"  [RELATORIO] {name} gerado com {len(df)} linhas.")

print("=" * 60)
print("  LH Nautical - Script 07: Análise Fase 2 (Supply & RH)")
print("=" * 60)

# Carregando tabelas necessárias
dim_suppliers = read_processed('dim_suppliers.csv')
dim_employees = read_processed('dim_employees.csv')
dim_addresses = read_processed('dim_addresses.csv')
fato_compras = read_processed('fato_compras.csv')
fato_fiscal = read_processed('fato_fiscal.csv')
fato_vendas = read_processed('fato_vendas.csv')

# ====================================================================
# 7A. PERFORMANCE DE FORNECEDORES (Supply Chain)
# ====================================================================
print("\nGerando 07a_performance_fornecedores.csv...")
# Calcula Total Gasto e Lead Time por Fornecedor
perf_forn = fato_compras.groupby('supplier_id').agg(
    qtd_compras=('purchase_order_id', 'nunique'),
    total_gasto=('total', 'sum'),
    lead_time_medio=('lead_time_days', 'mean'),
    atraso_medio=('delay_days', 'mean')
).reset_index()

perf_forn = perf_forn.merge(dim_suppliers[['supplier_id', 'legal_name', 'country']], on='supplier_id', how='left')
perf_forn = perf_forn[['supplier_id', 'legal_name', 'country', 'qtd_compras', 'total_gasto', 'lead_time_medio', 'atraso_medio']]
perf_forn = perf_forn.sort_values('total_gasto', ascending=False)
save_report(perf_forn, '07a_performance_fornecedores.csv')

# ====================================================================
# 7B. VENDAS POR ESTADO (Logística)
# ====================================================================
print("Gerando 07b_vendas_por_estado.csv...")
# Cruzando vendas com endereços
# Nota: Vamos usar endereços do tipo 'shipping' preferencialmente, senao 'billing'
enderecos_unicos = dim_addresses.sort_values(['customer_id', 'address_type']).drop_duplicates('customer_id')

vendas_geoloc = fato_vendas.merge(enderecos_unicos[['customer_id', 'state', 'city', 'country']], on='customer_id', how='left')
vendas_geoloc['state'] = vendas_geoloc['state'].fillna('Desconhecido')

vendas_estado = vendas_geoloc.groupby('state').agg(
    receita_total=('line_total', 'sum'),
    qtd_pedidos=('order_id', 'nunique')
).reset_index().sort_values('receita_total', ascending=False)
save_report(vendas_estado, '07b_vendas_por_estado.csv')

# ====================================================================
# 7C. PERFORMANCE DE VENDEDORES (RH)
# ====================================================================
print("Gerando 07c_performance_vendedores.csv...")
# Apenas vendas POS (Lojas físicas) e onde haja salesperson
fato_vendas_pos = fato_vendas[(fato_vendas['channel'] == 'pos') & (fato_vendas['salesperson_id'].notna())]

perf_vend = fato_vendas_pos.groupby('salesperson_id').agg(
    receita_gerada=('line_total', 'sum'),
    qtd_vendas=('order_id', 'nunique')
).reset_index()

perf_vend = perf_vend.merge(dim_employees[['employee_id', 'full_name', 'role', 'is_active']], left_on='salesperson_id', right_on='employee_id', how='left')
perf_vend = perf_vend[['salesperson_id', 'full_name', 'role', 'is_active', 'qtd_vendas', 'receita_gerada']]
perf_vend = perf_vend.sort_values('receita_gerada', ascending=False)
save_report(perf_vend, '07c_performance_vendedores.csv')

# ====================================================================
# 7D. RISCO FISCAL POR MÊS (Auditoria)
# ====================================================================
print("Gerando 07d_risco_fiscal_por_mes.csv...")
# Identifica vendas pagas/entregues sem NF-e
vendas_pagas = fato_vendas[fato_vendas['status'].isin(['paid', 'confirmed', 'delivered'])]
nfe_autorizada = fato_fiscal[fato_fiscal['status'] == 'authorized']

pedidos_pagos = vendas_pagas[['order_id', 'year', 'month', 'line_total']].copy()
pedidos_com_nfe = nfe_autorizada['order_id'].unique()

pedidos_pagos['tem_nfe'] = pedidos_pagos['order_id'].isin(pedidos_com_nfe)
pedidos_risco = pedidos_pagos[~pedidos_pagos['tem_nfe']]

risco_mes = pedidos_risco.groupby(['year', 'month']).agg(
    qtd_pedidos_sem_nfe=('order_id', 'nunique'),
    receita_nao_faturada=('line_total', 'sum')
).reset_index().sort_values(['year', 'month'])
save_report(risco_mes, '07d_risco_fiscal_por_mes.csv')

print("\n[CONCLUIDO] Script 07 finalizado com sucesso.")
