"""
=======================================================================
run_all.py - Executor Principal - LH Nautical Data Challenge
=======================================================================
Execute este script para rodar todo o pipeline de ponta a ponta:
  01 - EDA e Qualidade dos Dados
  02 - Tratamento e Modelagem
  03 - Analise de Vendas e Clientes
  04 - Previsao de Demanda e Recomendacao
  05 - Geracao do Dashboard HTML

Uso:
  python run_all.py
=======================================================================
"""

import subprocess
import sys
import os
import time

BASE_DIR = r"C:\Users\vanes\source\repos\nautical"
scripts  = [
    ("01_eda.py",                   "EDA e Qualidade dos Dados"),
    ("02_tratamento_modelagem.py",  "Tratamento e Modelagem"),
    ("03_analise_vendas_clientes.py","Analise de Vendas e Clientes"),
    ("04_previsao_recomendacao.py", "Previsao e Recomendacao"),
    ("07_analise_fase2.py",         "Analise Fase 2"),
    ("05_dashboard.py",             "Geracao do Dashboard"),
]

def run(script_name, desc):
    path = os.path.join(BASE_DIR, script_name)
    print(f"\n{'='*60}")
    print(f"  Executando: {desc}")
    print(f"  Script: {script_name}")
    print(f"{'='*60}")
    t0 = time.time()
    result = subprocess.run([sys.executable, path], capture_output=False)
    elapsed = time.time() - t0
    if result.returncode == 0:
        print(f"\n  [OK] Concluido em {elapsed:.1f}s")
    else:
        print(f"\n  [ERRO] Script falhou com codigo {result.returncode}")
    return result.returncode

print("\n" + "="*60)
print("  LH Nautical - Pipeline Completo de Dados")
print("  Rodando todos os scripts em sequencia...")
print("="*60)

erros = []
for script, desc in scripts:
    code = run(script, desc)
    if code != 0:
        erros.append(script)

print("\n" + "="*60)
print("  RESULTADO FINAL")
print("="*60)
if not erros:
    print("  [SUCESSO] Pipeline completo executado sem erros!")
    dashboard = os.path.join(BASE_DIR, "outputs", "dashboard_lh_nautical.html")
    print(f"\n  Dashboard disponivel em:\n  {dashboard}")
else:
    print(f"  [ATENCAO] {len(erros)} script(s) com erro: {', '.join(erros)}")
print("="*60)
